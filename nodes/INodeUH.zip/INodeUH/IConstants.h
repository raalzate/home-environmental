
#define MQTT_SERVER  “192.168.0.23”//host of respberry
#define AP_SSID  "SensorUseHome"// SSID access point
#define AP_PASSWORD  "12345678"// password access point

#define LED_STATUS_SEND LED_BUILTIN //D1
#define LED_STATUS_OUTSERVICE 4 //D2
#define LED_STATUS_INSERVICE 0 //D3

